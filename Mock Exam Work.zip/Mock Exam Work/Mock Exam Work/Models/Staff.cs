﻿namespace Mock_Exam_Work.Models
{
    public class Staff
    {
        public int StaffId { get; set; }
        public required string JobTitle { get; set; }
        public required string StaffFullName { get; set; }
        public required string Bio { get; set; }
    }
}
